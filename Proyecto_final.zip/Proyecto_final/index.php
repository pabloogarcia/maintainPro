<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestor de Mantenimiento Vehicular</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

    <link rel="stylesheet" href="frontend/css/index.css">
</head>
<body>

    <!-- Barra de Navegación -->
    <nav class="navbar">
        <div class="navbar-logo">
            <img src="logo/logo.png" alt="Logo">
        </div>
        <div>
            <?php if (isset($_SESSION["usuario_id"])): ?>
                <a href="dashboard.php" class="btn btn-primary">Dashboard</a>
                <a href="logout.php" class="btn btn-danger">Salir</a>
            <?php else: ?>
                <a href="login.php?mostrar=registro" class="btn btn-primary">Registrarse</a>
                <a href="login.php" class="btn btn-primary">Iniciar Sesión</a>
            <?php endif; ?>
        </div>
    </nav>  

    <!-- Hero Section -->
    <div class="hero">
        <h1>Tu vehículo, siempre en las mejores condiciones</h1>/
        <p>Monitorea mantenimientos, recibe alertas y optimiza la vida útil de tu coche.</p>
        <a href="login.php?mostrar=registro">Comenzar</a>
    </div>

    <!-- Secciones informativas -->
    <div class="section">
        <h2>¿Cómo Funciona?</h2>
        <p>Conectamos tu vehículo con un sistema inteligente que te avisa cuándo es momento de hacer mantenimiento.</p>
    </div>

    <div class="cards-container">
        <div class="card">
            <h3>Alertas Inteligentes</h3>
            <p>Recibe notificaciones cuando tu coche necesite atención.</p>
        </div>
        <div class="card">
            <h3>Historial Digital</h3>
            <p>Accede a todos los mantenimientos desde cualquier dispositivo.</p>
        </div>
        <div class="card">
            <h3>Consejos Personalizados</h3>
            <p>Obtén recomendaciones basadas en tu uso.</p>
        </div>
    </div>

    <div class="section">
        <h2>Beneficios del Sistema</h2>
    </div>
    <div class="cards-container">
        <div class="card">
            <h3>Evita Costos Innecesarios</h3>
            <p>Un mantenimiento a tiempo puede ahorrarte miles en reparaciones.</p>
        </div>
        <div class="card">
            <h3>Mayor Seguridad</h3>
            <p>Detecta problemas antes de que se conviertan en fallos peligrosos.</p>
        </div>
        <div class="card">
            <h3>100% Digital</h3>
            <p>Olvídate de los papeles y gestiona todo desde la app.</p>
        </div>
    </div>


    <!-- Pie de Página -->
    <footer>
        © 2025 - MaintainPro
    </footer>


</body>
</html>
