window.addEventListener("load", () => {
  // Esperamos un momento antes de empezar la transición
  setTimeout(() => {
    // Animar salida del overlay
    gsap.to("#welcome-overlay", {
      opacity: 0,
      duration: 1.2,
      ease: "power2.out",
      onComplete: () => {
        document.getElementById("welcome-overlay").style.display = "none";

        // Animamos el dashboard (ya debes tener estas líneas, pero puedes ajustar tiempos)
        gsap.to(".content", { opacity: 1, y: 0, duration: 1, delay: 0.5 });
        gsap.utils.toArray(".card").forEach((card, index) => {
          gsap.to(card, {
            opacity: 1,
            y: 0,
            duration: 1,
            delay: 0.8 + index * 0.2,
          });
        });
      },
    });
  }, 2500); // Tiempo visible del panel de bienvenida
});

// Inicia partículas en el fondo
tsParticles.load("tsparticles", {
  background: {
    color: { value: "#1e272e" },
  },
  fpsLimit: 60,
  particles: {
    number: {
      value: 40,
      density: { enable: true, value_area: 800 },
    },
    color: { value: "#08d9c8" },
    shape: { type: "circle" },
    opacity: {
      value: 0.5,
      random: true,
    },
    size: {
      value: { min: 1, max: 5 },
    },
    move: {
      enable: true,
      speed: 1,
      direction: "none",
      outMode: "out",
    },
    links: {
      enable: true,
      distance: 120,
      color: "#08d9c8",
      opacity: 0.4,
      width: 1,
    },
  },
  interactivity: {
    events: {
      onHover: { enable: true, mode: "repulse" },
    },
    modes: {
      repulse: { distance: 100, duration: 0.4 },
    },
  },
  detectRetina: true,
});

document.addEventListener("DOMContentLoaded", () => {
  const botones = document.querySelectorAll(".btn-notificar");

  botones.forEach((boton) => {
    boton.addEventListener("click", async (e) => {
      e.preventDefault();
      const id = boton.getAttribute("data-id");

      const confirmacion = confirm(
        "¿Quieres enviar el recordatorio de mantenimiento ahora?"
      );
      if (!confirmacion) return;

      const res = await fetch(
        `../backend/controllers/notificar_mantenimiento.php?id=${id}`
      );
      const data = await res.json();

      if (data.status === "success") {
        alert("Correo de mantenimiento enviado con éxito.");
      } else {
        alert("Hubo un problema al enviar el correo.");
      }
    });
  });
});
