/*CREATE DATABASE mantenimiento_vehiculos;
-- CREAR TABLA usuarios
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    contraseña VARCHAR(255),
    imagen_perfil LONGBLOB
);

-- CREAR TABLA vehiculos_guardados
CREATE TABLE vehiculos_guardados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    año VARCHAR(10),
    marca VARCHAR(100),
    modelo VARCHAR(100),
    version VARCHAR(100),
    fecha_guardado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ultima_revision DATE,
    proxima_revision DATE,
    itv_fecha DATE DEFAULT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- CREAR TABLA notificaciones_vehiculo
CREATE TABLE notificaciones_vehiculo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehiculo_id INT NOT NULL,
    mensaje VARCHAR(255),
    fecha_notificacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    leido BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (vehiculo_id) REFERENCES vehiculos_guardados(id) ON DELETE CASCADE
);
*/

/*
SELECT 
    id,
    marca,
    modelo,
    itv_fecha,
    DATE_ADD(itv_fecha, INTERVAL 1 YEAR) AS proxima_itv,
    DATEDIFF(DATE_ADD(itv_fecha, INTERVAL 1 YEAR), CURDATE()) AS dias_para_itv
FROM vehiculos_guardados
WHERE itv_fecha IS NOT NULL
  AND DATEDIFF(DATE_ADD(itv_fecha, INTERVAL 1 YEAR), CURDATE()) BETWEEN 0 AND 7;
*/