<?php
session_start();
if (!isset($_SESSION["usuario_id"])) {
    header("Location: login.php");
    exit();
}

require_once 'backend/config/db.php';

$usuario_id = $_SESSION["usuario_id"];

$sql = "SELECT nombre, imagen_perfil FROM usuarios WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$stmt->bind_result($nombre, $imagen);
$stmt->fetch();
$stmt->close();

$imagen_perfil = empty($imagen)
    ? "https://www.kindpng.com/picc/m/24-248253_user-profile-default-image-png-clipart-png-download.png"
    : "backend/controllers/mostrar_imagen.php?id=$usuario_id";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/tsparticles@2.11.1/tsparticles.bundle.min.js"></script>


    <link rel="stylesheet" href="frontend/css/dashboard.css">
</head>
<body>
    <div id="welcome-overlay" class="welcome-overlay">
        <div id="tsparticles"></div>
        <div class="welcome-content">
            <h1 class="animate__animated animate__fadeInDown">¡Hola, <?php echo $_SESSION["nombre"]; ?>!</h1>
            <p class="animate__animated animate__fadeInUp animate__delay-1s">Bienvenido al panel de mantenimiento de MaintainPro</p>
        </div>
    </div>


    <!-- Barra de Navegación -->
    <nav class="navbar">
        <div class="navbar-logo">
            <img src="logo/logo.png" alt="Logo">
            
        </div>
        <div>
            <a href="dashboard.php"> Inicio</a>
            <a href="mis_vehiculos.php">Mis Vehículos</a>
            <a href="buscar_mantenimientos.php">Buscar Mantenimientos</a>
            <a href="itv.php">Actualizar ITV</a>
        </div>

        <div>
            <?php if (isset($_SESSION["usuario_id"])): ?>
                <a href="perfil.php">
                <img src="<?php echo $imagen_perfil; ?>" alt="Perfil" class="perfil-img">
                    <span><?php echo $_SESSION["nombre"]; ?></span>
                </a>
                <a href="logout.php" id="logout">Cerrar Sesión</a>
            <?php else: ?>
                <a href="login.php">Iniciar Sesión</a>
                <a href="login.php#register">Registrarse</a>
            <?php endif; ?>
        </div>
    </nav>
 

    <div class="content">
        <h2>Bienvenido, <?php echo $_SESSION["nombre"]; ?> </h2>
        <p>Gestiona fácilmente el mantenimiento de tus vehículos.</p>

        <div class="card-container">
            <div class="card">
                <h3> Estado del Vehículo</h3>
                <p>Consulta el estado actual de tus vehículos registrados.</p>
            </div>
            <div class="card">
                <h3> Próximos Mantenimientos</h3>
                <p>Revisa los mantenimientos programados para evitar problemas.</p>
            </div>
            <div class="card">
                <h3> Historial</h3>
                <p>Accede al historial completo de mantenimientos realizados.</p>
            </div>
        </div>
    </div>
    <script src="frontend/js/dashboard.js"></script>
</body>
</html>