<?php 
session_start();
if (!isset($_SESSION["usuario_id"])) {
    header("Location: login.php");
    exit();
}

require_once 'backend/config/db.php';

$año    = $_GET['año']    ?? '';
$marca   = $_GET['marca']   ?? '';
$modelo  = $_GET['modelo']  ?? '';
$version = $_GET['version'] ?? '';
$usuario_id = $_SESSION["usuario_id"];

// Buscar si el vehículo ya está guardado
$sql = "SELECT * FROM vehiculos_guardados 
        WHERE usuario_id = ? AND año = ? AND marca = ? AND modelo = ? AND version = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("issss", $usuario_id, $año, $marca, $modelo, $version);
$stmt->execute();
$resultado = $stmt->get_result();
$vehiculo = $resultado->fetch_assoc();

// Si se envió el formulario para actualizar mantenimiento
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fecha_revision'])) {
    $fecha_revision = $_POST['fecha_revision'];

    if ($vehiculo) {
        $sqlUpdate = "UPDATE vehiculos_guardados 
                      SET ultima_revision = ?, proxima_revision = DATE_ADD(?, INTERVAL 1 YEAR) 
                      WHERE id = ?";
        $stmtUpdate = $conexion->prepare($sqlUpdate);
        $stmtUpdate->bind_param("ssi", $fecha_revision, $fecha_revision, $vehiculo['id']);
        $stmtUpdate->execute();
        $_SESSION['mensaje_exito'] = "Revisión actualizada correctamente.";
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit();
    } else {
        $sqlInsert = "INSERT INTO vehiculos_guardados (usuario_id, año, marca, modelo, version, ultima_revision, proxima_revision) 
                      VALUES (?, ?, ?, ?, ?, ?, DATE_ADD(?, INTERVAL 1 YEAR))";
        $stmtInsert = $conexion->prepare($sqlInsert);
        $stmtInsert->bind_param("issssss", $usuario_id, $año, $marca, $modelo, $version, $fecha_revision, $fecha_revision);
        $stmtInsert->execute();
        $_SESSION['mensaje_exito'] = " Vehículo registrado y mantenimiento actualizado.";
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit();
    }
}

$sql = "SELECT nombre, imagen_perfil FROM usuarios WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$stmt->bind_result($nombre, $imagen);
$stmt->fetch();
$stmt->close();

$imagen_perfil = empty($imagen)
    ? "https://www.kindpng.com/picc/m/24-248253_user-profile-default-image-png-clipart-png-download.png"
    : "backend/controllers/mostrar_imagen.php?id=$usuario_id";
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mantenimientos - <?php echo "$año $marca $modelo $version"; ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
  <link rel="stylesheet" href="frontend/css/ver_mantenimientos.css">
</head>
<body>
<nav class="navbar">
  <div class="navbar-logo">
    <img src="logo/logo.png" alt="Logo">
  </div>
  <div>
    <a href="dashboard.php" id="links">Inicio</a>
    <a href="mis_vehiculos.php" id="links">Mis Vehículos</a>
    <a href="buscar_mantenimientos.php" id="links">Buscar Mantenimientos</a>
    <a href="itv.php">Actualizar ITV</a>
  </div>
  <div>
    <a href="perfil.php">
      <img src="<?php echo $imagen_perfil; ?>" alt="Perfil" class="perfil-img">
      <span><?php echo $_SESSION["nombre"]; ?></span>
    </a>
    <a href="logout.php" id="logout">Cerrar Sesión</a>
  </div>
</nav>
  <?php if (isset($_SESSION['mensaje_exito'])): ?>
          <div id="mensajeExito" class="mensaje-exito"><?= $_SESSION['mensaje_exito']; ?></div>
          <?php unset($_SESSION['mensaje_exito']); ?>
      <?php endif; ?>

      <?php if (isset($_SESSION['mensaje_error'])): ?>
          <div id="mensajeError" class="mensaje-error"><?= $_SESSION['mensaje_error']; ?></div>
          <?php unset($_SESSION['mensaje_error']); ?>
      <?php endif; ?>

<div class="main-content">
    <div class="container">
      <h2 class="animate__animated animate__fadeInDown">Mantenimientos para: <?php echo "$año $marca $modelo $version"; ?></h2>

      <!-- Formulario de actualización de mantenimiento -->
      <form method="POST" >
        <label for="fecha_revision">Actualizar mantenimiento (fecha de revisión realizada):</label>
        <input type="date" name="fecha_revision" class="form-control mb-3" required>
        <button type="submit" class="btn btn-success">Guardar vehículo o actualizar mantenimiento</button>
      </form>

      <?php
      $mantenimientoData = null;
      if ($año && $marca && $modelo && $version) {
          $baseUrl = "http://localhost/Proyecto_final/";
          $url = sprintf("%sbackend/api/api_mantenimiento.php?año=%s&marca=%s&modelo=%s&version=%s",
              $baseUrl,
              urlencode($año),
              urlencode($marca),
              urlencode($modelo),
              urlencode($version)
          );
          $respuesta = file_get_contents($url);
          $mantenimientoData = json_decode($respuesta, true);
      }
      ?>

      <?php if ($mantenimientoData && isset($mantenimientoData['status']) && $mantenimientoData['status'] === 'success'): ?>
        <h3 class="animate__animated animate__fadeInUp">Kilometrajes de mantenimiento:</h3>
        <ul id="kilometraje-lista">
          <?php foreach ($mantenimientoData['data']['maintenance'] as $mantenimiento): ?>
            <li class="kilometraje-link" data-km="<?php echo $mantenimiento['mileage']; ?>">
              <?php echo $mantenimiento['mileage']; ?> km
            </li>
          <?php endforeach; ?>
        </ul>

        <div id="mantenimiento-detalles">
          <div id="servicios"></div>
          <div id="costos"></div>
        </div>

      <?php else: ?>
        <p>No se encontraron mantenimientos para este vehículo.</p>
      <?php endif; ?>
    </div>
</div>

  <script>
    const linksKilometraje = document.querySelectorAll('.kilometraje-link');
    const mantenimientoDetalles = document.getElementById('mantenimiento-detalles');
    const serviciosDiv = document.getElementById('servicios');
    const costosDiv = document.getElementById('costos');

    linksKilometraje.forEach(link => {
      link.addEventListener('click', (event) => {
        event.preventDefault();
        const kmSeleccionado = link.getAttribute('data-km');
        const mantenimiento = <?php echo json_encode($mantenimientoData['data']['maintenance']); ?>;
        const mantenimientoSeleccionado = mantenimiento.find(item => item.mileage == kmSeleccionado);

        gsap.to(mantenimientoDetalles, {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: "power2.out"
        });

        serviciosDiv.innerHTML = `
          <h5>Servicios <strong>${kmSeleccionado}</strong> km:</h5>
          <ul>
            ${mantenimientoSeleccionado.normal.service_items.map(servicio => `<li>${servicio}</li>`).join('')}
          </ul>
        `;

        if (mantenimientoSeleccionado.severe && mantenimientoSeleccionado.severe.costs) {
          const { high, low, average } = mantenimientoSeleccionado.severe.costs;
          costosDiv.innerHTML = `
            <h5>Costos:</h5>
            <p class="con-costos">
              Alta: $${high}, 
              Baja: $${low}, 
              Promedio: $${average}
            </p>
          `;
        } else {
          costosDiv.innerHTML = `<p>No se encontraron costos para este mantenimiento.</p>`;
        }

        document.getElementById('mantenimiento-detalles').scrollIntoView({ behavior: 'smooth' });
      });
    });
  </script>

  <script>
  document.addEventListener("DOMContentLoaded", function () {
    const mensajeExito = document.getElementById('mensajeExito');
    const mensajeError = document.getElementById('mensajeError');

    if (mensajeExito) {
      setTimeout(() => {
        mensajeExito.classList.add("fade-out");
        setTimeout(() => mensajeExito.remove(), 1000);
      }, 4000);
    }

    if (mensajeError) {
      setTimeout(() => {
        mensajeError.classList.add("fade-out");
        setTimeout(() => mensajeError.remove(), 1000);
      }, 4000);
    }
  });
  </script>
</body>
</html>
