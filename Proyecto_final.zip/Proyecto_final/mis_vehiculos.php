<?php 
session_start();
require 'backend/config/db.php';

if (!isset($_SESSION["usuario_id"])) {
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION["usuario_id"];
$stmt = $conexion->prepare("SELECT * FROM vehiculos_guardados WHERE usuario_id = ?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$resultado = $stmt->get_result();

$sql = "SELECT nombre, imagen_perfil FROM usuarios WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$stmt->bind_result($nombre, $imagen);
$stmt->fetch();
$stmt->close();

$_SESSION["nombre"] = $nombre; 

$imagen_perfil = empty($imagen)
    ? "https://www.kindpng.com/picc/m/24-248253_user-profile-default-image-png-clipart-png-download.png"
    : "backend/controllers/mostrar_imagen.php?id=$usuario_id";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Vehículos</title>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="frontend/css/mis_vehiculos.css">
</head>
<body>
<nav class="navbar">
    <div class="navbar-logo">
        <img src="logo/logo.png" alt="Logo">
    </div>
    <div>
        <a href="dashboard.php">Inicio</a>
        <a href="mis_vehiculos.php">Mis Vehículos</a>
        <a href="buscar_mantenimientos.php">Buscar Mantenimientos</a>
        <a href="itv.php">Actualizar ITV</a>
    </div>
    <div>
        <?php if (isset($_SESSION["usuario_id"])): ?>
            <a href="perfil.php">
                <img src="<?php echo $imagen_perfil; ?>" alt="Perfil" class="perfil-img">
                <span><?php echo $_SESSION["nombre"]; ?></span>
            </a>
            <a href="logout.php" id="logout">Cerrar Sesión</a>
        <?php else: ?>
            <a href="login.php">Iniciar Sesión</a>
            <a href="login.php#register">Registrarse</a>
        <?php endif; ?>
    </div>
</nav>

<div class="content">
    <?php if (isset($_SESSION['mensaje_exito'])): ?>
        <div id="mensajeExito" class="mensaje-exito"><?= $_SESSION['mensaje_exito']; ?></div>
        <?php unset($_SESSION['mensaje_exito']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['mensaje_error'])): ?>
        <div id="mensajeError" class="mensaje-error"><?= $_SESSION['mensaje_error']; ?></div>
        <?php unset($_SESSION['mensaje_error']); ?>
    <?php endif; ?>
    
    <h2>Mis Vehículos Guardados</h2>

    <?php
    function obtenerImagenCocheGoogle($año, $marca, $modelo) {
        $apiKey = 'AIzaSyDmwY5PYDw47tvaGcH7EJu60C4DcZtaClM'; 
        $cseId = '80123c1563a034d0c'; 
        $searchTerm = urlencode($año . ' ' . $marca . ' ' . $modelo . ' side profile png transparent carsized -drawing -clipart -toy');
        $url = "https://www.googleapis.com/customsearch/v1?q=$searchTerm&key=$apiKey&cx=$cseId&searchType=image&num=1";
        $response = @file_get_contents($url);
        if ($response) {
            $data = json_decode($response, true);
            if (isset($data['items'][0]['link'])) {
                return $data['items'][0]['link'];
            }
        }
        return 'default_car_image.jpg';
    }
    ?>

    <?php while ($vehiculo = $resultado->fetch_assoc()): ?>
        <?php
            $ultimaRevision = $vehiculo['ultima_revision'];
            $proximaRevision = $ultimaRevision ? date('Y-m-d', strtotime($ultimaRevision . ' +1 year')) : 'No disponible';
            $hoy = date('Y-m-d');
            $imagenCoche = obtenerImagenCocheGoogle($vehiculo['año'], $vehiculo['marca'], $vehiculo['modelo']);

            $añoMatriculacion = (int)$vehiculo['año'];
            $añosTranscurridos = (int)date('Y') - $añoMatriculacion;
            $fechaItv = $vehiculo['itv_fecha'];
        ?>
        <div class="card">
            <h3><?= "{$vehiculo['año']} {$vehiculo['marca']} {$vehiculo['modelo']} {$vehiculo['version']}" ?></h3>
            <div class="card-image">
                <img src="<?= htmlspecialchars($imagenCoche); ?>" alt="Imagen del coche" class="car-img">
            </div>

            <div class="maintenance-dates">
                <?php if ($ultimaRevision): ?>
                    <p class="revision-info"><strong>Última revisión:</strong> <?= $ultimaRevision ?></p>
                    <?php if ($proximaRevision !== 'No disponible' && $proximaRevision < $hoy): ?>
                        <p class="revision-info"><strong class="revision-vencida">¡Pasar revisión!</strong> <span class="revision-vencida">(Venció el <?= $proximaRevision ?>)</span></p>
                    <?php else: ?>
                        <p class="revision-info"><strong>Próxima revisión:</strong> <span class="revision-proxima"><?= $proximaRevision ?></span></p>
                    <?php endif; ?>
                <?php else: ?>
                    <p class="revision-info"><em class="revision-nodisponible">Sin revisión registrada.</em></p>
                <?php endif; ?>

                <!-- Estado ITV -->
                <p class="revision-info"><strong>ITV:</strong>
                    <?php if ($añosTranscurridos < 4): ?>
                        <span class="revision-proxima">Exento hasta <?= ($añoMatriculacion + 4) ?></span>
                    <?php elseif ($fechaItv): ?>
                        <?php
                        $fechaItvValidez = date('Y-m-d', strtotime($fechaItv . ' +1 year'));
                        ?>
                        <?php if ($fechaItvValidez < $hoy): ?>
                            <span class="revision-vencida">ITV vencida desde <?= $fechaItvValidez ?></span>
                        <?php else: ?>
                            <span class="revision-proxima">ITV vigente hasta <?= $fechaItvValidez ?></span>
                        <?php endif; ?>
                    <?php else: ?>
                        <em class="revision-nodisponible">No disponible</em>
                    <?php endif; ?>
                </p>

            </div>

            <div class="card-buttons">
                <a href="ver_mantenimientos.php?año=<?= urlencode($vehiculo['año']); ?>&marca=<?= urlencode($vehiculo['marca']); ?>&modelo=<?= urlencode($vehiculo['modelo']); ?>&version=<?= urlencode($vehiculo['version']); ?>" class="ver-btn">Ver Mantenimientos y actualizar</a>

                <button class="btn-notificar notificar-btn" data-id="<?= $vehiculo['id']; ?>">Notificar mantenimiento</button>

                <a href="itv.php?id=<?= $vehiculo['id'] ?>" class="btn-actualizar-itv">Actualizar ITV</a>

                <form action="backend/controllers/borrar_vehiculo.php" method="GET" onsubmit="return confirm('¿Estás seguro de eliminar este vehículo?');" style="display: inline;">
                    <input type="hidden" name="id" value="<?= $vehiculo['id']; ?>">
                    <button type="submit" class="btn-danger eliminar-btn">Eliminar Vehículo</button>
                </form>
            </div>
        </div>
    <?php endwhile; ?>

    <a href="dashboard.php" class="btn-primary">Volver al inicio</a>
</div>

<script>
       document.addEventListener("DOMContentLoaded", function () {
    // Revisa si ya hay mensajes de éxito o error en la página (por ejemplo, si se han mostrado en la sesión)
    const mensajeExito = document.getElementById('mensajeExito');
    const mensajeError = document.getElementById('mensajeError');

    // Si hay un mensaje de éxito o error, asegurarse de que la página se desplace hacia arriba
    if (mensajeExito || mensajeError) {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'  // Desplazamiento suave
        });
    }

    // Asegúrate de manejar la animación de la notificación
    if (mensajeExito) {
        setTimeout(() => {
            mensajeExito.classList.add("fade-out");
            setTimeout(() => mensajeExito.remove(), 1000);
        }, 4000);
    }

    if (mensajeError) {
        setTimeout(() => {
            mensajeError.classList.add("fade-out");
            setTimeout(() => mensajeError.remove(), 1000);
        }, 4000);
    }
});

// Función para manejar los botones de notificación
document.addEventListener("DOMContentLoaded", function() {
    const botonesNotificar = document.querySelectorAll('.btn-notificar');

    botonesNotificar.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            const vehiculoId = button.getAttribute('data-id');

            fetch(`backend/controllers/notificar_mantenimiento.php?id=${vehiculoId}`)
                .then(response => response.json())
                .then(data => {
                    const mensajeContainer = document.createElement('div');
                    if (data.status === 'success') {
                        mensajeContainer.classList.add('mensaje-exito');
                        mensajeContainer.textContent = data.message || "Notificación enviada correctamente.";
                    } else {
                        mensajeContainer.classList.add('mensaje-error');
                        mensajeContainer.textContent = `Error al enviar la notificación: ${data.message}`;
                    }

                    // Añadir el mensaje al contenido
                    const content = document.querySelector('.content');
                    content.insertBefore(mensajeContainer, content.firstChild);

                    // Desplazar la página hacia el principio de la página
                    window.scrollTo({
                        top: 0, // Se mueve al principio de la página
                        behavior: 'smooth' // Desplazamiento suave
                    });

                    // Eliminar el mensaje después de un tiempo
                    setTimeout(() => {
                        mensajeContainer.classList.add("fade-out");
                        setTimeout(() => mensajeContainer.remove(), 1000); // Espera a que termine y lo elimina
                    }, 4000); // Espera 4 segundos antes de empezar la animación
                })
                .catch(error => {
                    console.error('Error:', error);
                    const mensajeContainer = document.createElement('div');
                    mensajeContainer.classList.add('mensaje-error');
                    mensajeContainer.textContent = "Hubo un problema con la solicitud.";

                    // Añadir el mensaje de error al contenido
                    const content = document.querySelector('.content');
                    content.insertBefore(mensajeContainer, content.firstChild);

                    // Desplazar la página hacia el principio de la página
                    window.scrollTo({
                        top: 0, // Se mueve al principio de la página
                        behavior: 'smooth' // Desplazamiento suave
                    });

                    // Eliminar el mensaje después de un tiempo
                    setTimeout(() => {
                        mensajeContainer.classList.add("fade-out");
                        setTimeout(() => mensajeContainer.remove(), 1000); // Espera a que termine y lo elimina
                    }, 4000); // Espera 4 segundos antes de empezar la animación
                });
        });
    });
});
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const mensaje = document.getElementById("mensajeExito");
            if (mensaje) {
                setTimeout(() => {
                    mensaje.classList.add("fade-out"); // Aplica desvanecimiento
                    setTimeout(() => mensaje.remove(), 1000); // Espera a que termine y lo elimina
                }, 4000); // Espera 4s antes de empezar la animación
            }
        });
        </script>

</body>
</html>
