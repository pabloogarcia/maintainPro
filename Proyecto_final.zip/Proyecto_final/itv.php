<?php

require_once 'backend/config/db.php';

// Ejecuta lógica de la ITV
$data = require __DIR__ . '/backend/controllers/actualizar_itv.php';
extract($data);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Actualizar ITV</title>
  <link rel="stylesheet" href="frontend/css/itv.css" />
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo">
      <img src="logo/logo.png" alt="Logo" />
    </div>
    <div>
      <a href="dashboard.php">Inicio</a>
      <a href="mis_vehiculos.php">Mis Vehículos</a>
      <a href="buscar_mantenimientos.php">Buscar Mantenimientos</a>
      <a href="itv.php">Actualizar ITV</a>
    </div>
    <div>
      <?php if (isset($_SESSION["usuario_id"])): ?>
        <a href="perfil.php">
          <img src="<?php echo $imagen_perfil; ?>" alt="Perfil" class="perfil-img" />
          <span><?php echo htmlspecialchars($nombre); ?></span>
        </a>
        <a href="logout.php" id="logout">Cerrar Sesión</a>
      <?php else: ?>
        <a href="login.php">Iniciar Sesión</a>
        <a href="login.php#register">Registrarse</a>
      <?php endif; ?>
    </div>
  </nav>

  <div class="content">
    <h2>Actualizar ITV</h2>

    <?php if (!empty($mensaje_exito)) : ?>
      <div class="mensaje-exito"><?php echo $mensaje_exito; ?></div>
    <?php elseif (!empty($mensaje_error)) : ?>
      <div class="mensaje-error"><?php echo $mensaje_error; ?></div>
    <?php endif; ?>

    <div class="card">
      <h3>Actualizar revisión técnica</h3>
      <form method="POST" action="itv.php">
        <label for="id_vehiculo">Selecciona vehículo:</label><br>
        <select name="id_vehiculo" id="id_vehiculo" required>
          <option value="">-- Selecciona un vehículo --</option>
          <?php foreach ($vehiculos as $veh): ?>
            <option value="<?php echo $veh['id']; ?>"
              <?php echo (isset($vehiculo_seleccionado) && $vehiculo_seleccionado['id'] == $veh['id']) ? 'selected' : ''; ?>>
              <?php echo htmlspecialchars("{$veh['marca']} {$veh['modelo']} ({$veh['año']})"); ?>
            </option>
          <?php endforeach; ?>
        </select><br><br>

        <label for="fecha_itv">Fecha ultima ITV:</label><br>
        <input type="date" id="fecha_itv" name="fecha_itv" required
        value="<?php 
            echo isset($vehiculo_seleccionado['itv_fecha']) 
                ? htmlspecialchars($vehiculo_seleccionado['itv_fecha']) 
                : ''; 
        ?>"><br><br>
        
        <div class="card-buttons center">
          <button type="submit">Actualizar</button>
          <a href="mis_vehiculos.php" class="btn-primary">Cancelar</a>
        </div>
      </form>
    </div>
  </div>

  <div class="loading-overlay" id="loading">
    <div class="loading-spinner"></div>
  </div>

  <script>
    document.querySelector("form")?.addEventListener("submit", function () {
      document.getElementById("loading").style.display = "flex";
    });
  </script>
</body>
</html>
