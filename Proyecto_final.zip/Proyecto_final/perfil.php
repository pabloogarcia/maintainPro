    <?php
    session_start();
    require 'backend/config/db.php';

    if (!isset($_SESSION['usuario_id'])) {
        header("Location: login.php");
        exit;
    }

    $usuario_id = $_SESSION['usuario_id'];

    // Obtener datos del usuario
    $sql = "SELECT nombre, email, imagen_perfil FROM usuarios WHERE id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $stmt->bind_result($nombre, $email, $imagen);
    $stmt->fetch();
    $stmt->close();

    // Ruta de la imagen de perfil
    if (empty($imagen)) {
        $imagen_perfil = "https://www.kindpng.com/picc/m/24-248253_user-profile-default-image-png-clipart-png-download.png";
    } else {
        $imagen_perfil = "backend/controllers/mostrar_imagen.php?id=" . $usuario_id;
    }
    ?>

    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <title>Editar Perfil</title>
        
        <link rel="stylesheet" href="frontend/css/perfil.css">
    </head>
    <body>
        <!-- Barra de Navegación -->
        <nav class="navbar">
            <div class="navbar-logo">
                <img src="logo/logo.png" alt="Logo">
            </div>
            <div>
                <a href="dashboard.php">Inicio</a>
                <a href="mis_vehiculos.php">Mis Vehículos</a>
                <a href="buscar_mantenimientos.php">Buscar Mantenimientos</a>
                <a href="itv.php">Actualizar ITV</a>
            </div>
            <div>
                <a href="perfil.php">
                    <img src="<?php echo $imagen_perfil; ?>" alt="Perfil" class="perfil-img">
                    <span><?php echo htmlspecialchars($nombre); ?></span>
                </a>
                <a href="logout.php" id="logout">Cerrar Sesión</a>
            </div>
        </nav>

        <!-- Alertas -->
        <div class="alert-container">
            <?php if (isset($_SESSION['error'])): ?>
                <div class="error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>
            <?php if (isset($_SESSION['mensaje'])): ?>
                <div class="mensaje"><?php echo $_SESSION['mensaje']; unset($_SESSION['mensaje']); ?></div>
            <?php endif; ?>
        </div>

        <div class="content">
            <div class="profile-info">
                <img src="<?php echo $imagen_perfil; ?>" alt="Imagen de perfil" class="perfil-img">
                <h3><?php echo htmlspecialchars($nombre); ?></h3>
                <p><?php echo htmlspecialchars($email); ?></p>
            </div>

            <h2>Modificar Datos</h2>
            <form action="backend/controllers/editar_perfil.php" method="POST">
                <div class="input-group">
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombre); ?>" required>
                </div>

                <div class="input-group">
                    <label for="email">Correo Electrónico:</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                </div>

                <button type="submit" name="accion" value="actualizar_datos">Guardar Datos</button>
            </form>

            <h2>Cambiar Contraseña</h2>
            <form action="backend/controllers/editar_perfil.php" method="POST">
                <div class="input-group">
                    <label for="password">Nueva Contraseña: </label>
                    <input type="password" id="password" name="password" required>
                </div>

                <button type="submit" name="accion" value="cambiar_contraseña">Cambiar Contraseña</button>
            </form>

            <h2>Actualizar Imagen de Perfil</h2>
            <form action="backend/controllers/editar_perfil.php" method="POST" enctype="multipart/form-data">
                <div class="input-group">
                    <label for="imagen_perfil">Imagen de Perfil:</label>
                    <input type="file" id="imagen_perfil" name="imagen_perfil" accept="image/*" required>
                </div>
                
                <button type="submit" name="accion" value="cambiar_imagen">Subir Imagen</button>
            </form>
        </div>

        <script>
        // Espera 4 segundos y luego oculta las alertas con una animación
        setTimeout(() => {
            document.querySelectorAll('.error, .mensaje').forEach(el => {
            el.style.transition = 'opacity 0.5s ease-out';
            el.style.opacity = '0';
            setTimeout(() => el.remove(), 500); // luego de desvanecer, eliminar el elemento
            });
        }, 4000);
        </script>

        <script>
        document.addEventListener("DOMContentLoaded", function () {
            const nombreInput = document.getElementById("nombre");
            const emailInput = document.getElementById("email");

            // Botón específico de guardar datos personales
            const guardarBtn = document.querySelector('button[name="accion"][value="actualizar_datos"]');

            const nombreOriginal = nombreInput.value;
            const emailOriginal = emailInput.value;

            function verificarCambios() {
                const haCambiado = nombreInput.value !== nombreOriginal || emailInput.value !== emailOriginal;
                guardarBtn.disabled = !haCambiado;
            }

            nombreInput.addEventListener("input", verificarCambios);
            emailInput.addEventListener("input", verificarCambios);

            // Desactivar inicialmente
            guardarBtn.disabled = true;
        });
        </script>

    </body>
    </html>

