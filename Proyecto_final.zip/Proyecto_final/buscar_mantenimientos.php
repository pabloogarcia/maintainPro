<?php
session_start();  

if (!isset($_SESSION["usuario_id"])) {
    header("Location: login.php"); 
    exit();
}

require_once 'backend/config/db.php';

$usuario_id = $_SESSION["usuario_id"];

$sql = "SELECT nombre, imagen_perfil FROM usuarios WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$stmt->bind_result($nombre, $imagen);
$stmt->fetch();
$stmt->close();

$imagen_perfil = empty($imagen)
    ? "https://www.kindpng.com/picc/m/24-248253_user-profile-default-image-png-clipart-png-download.png"
    : "backend/controllers/mostrar_imagen.php?id=$usuario_id";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Buscar Mantenimientos</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <link rel="stylesheet" href="frontend/css/dashboard.css">
    <link rel="stylesheet" href="frontend/css/buscar_mantenimientos.css"/>
    
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar">
        <div class="navbar-logo">
            <img src="logo/logo.png" alt="Logo">
        </div>
        <div>
            <a href="dashboard.php">Inicio</a>
            <a href="mis_vehiculos.php">Mis Vehículos</a>
            <a href="buscar_mantenimientos.php">Buscar Mantenimientos</a>
            <a href="itv.php">Actualizar ITV</a>
        </div>
        <div>
            <?php if (isset($_SESSION["usuario_id"])): ?>
                <a href="perfil.php">
                    <img src="<?php echo $imagen_perfil; ?>" alt="Perfil" class="perfil-img">
                    <span><?php echo htmlspecialchars($nombre); ?></span>
                </a>
                <a href="logout.php" id="logout">Cerrar Sesión</a>
            <?php else: ?>
                <a href="login.php">Iniciar Sesión</a>
                <a href="login.php#register">Registrarse</a>
            <?php endif; ?>
        </div>
    </nav>

    <div class="main-content">
        <div class="container">
            <h2 class="animate__animated animate__fadeInDown">Buscar Mantenimientos</h2>

            <div class="form-group">
                <label for="yearSelect">Año</label>
                <select id="yearSelect" name="año">
                    <option value="">Cargando...</option>
                </select>
            </div>

            <div class="form-group">
                <label for="makeSelect">Marca</label>
                <select id="makeSelect" name="marca" disabled>
                    <option value="">Selecciona un año primero</option>
                </select>
            </div>

            <div class="form-group">
                <label for="modelSelect">Modelo</label>
                <select id="modelSelect" name="modelo" disabled>
                    <option value="">Selecciona una marca primero</option>
                </select>
            </div>

            <div class="form-group">
                <label for="trimSelect">Versión</label>
                <select id="trimSelect" name="version" disabled>
                    <option value="">Selecciona un modelo primero</option>
                </select>
            </div>

            <button id="verMantenimientosBtn" disabled>Ver Mantenimientos</button>

            <div id="loadingOverlay" class="loading-overlay">
                <div class="loading-spinner"></div>
            </div>

        </div>
    </div>

    <script>
        const yearSelect = document.getElementById("yearSelect");
        const makeSelect = document.getElementById("makeSelect");
        const modelSelect = document.getElementById("modelSelect");
        const trimSelect = document.getElementById("trimSelect");
        const verMantenimientosBtn = document.getElementById("verMantenimientosBtn");
        const loadingOverlay = document.getElementById('loadingOverlay');

        function checkIfReadyToEnableButton() {
            verMantenimientosBtn.disabled = !(yearSelect.value && makeSelect.value && modelSelect.value && trimSelect.value);
        }

        async function getAños() {
            showLoading();  
            try {
                const res = await fetch("backend/api/api_años.php");
                const data = await res.json();
                console.log("Respuesta del backend:", data);
                if (data.status === "success" && data.data.years) {
                    yearSelect.innerHTML = `<option value="">Selecciona un año</option>`;
                    data.data.years.forEach(año => {
                        const option = document.createElement("option");
                        option.value = año;
                        option.textContent = año;
                        yearSelect.appendChild(option);
                    });
                } else {
                    yearSelect.innerHTML = `<option value="">No se pudieron cargar los años</option>`;
                }
            } catch (e) {
                console.error("Error al cargar los años:", e);
                yearSelect.innerHTML = `<option value="">Error al cargar los años</option>`;
            } finally {
                hideLoading();  
            }
        }

        async function getMarcas() {
            const año = yearSelect.value;
            if (!año) return;
            showLoading();
            try {
                const res = await fetch(`backend/api/api_marcas.php?año=${encodeURIComponent(año)}`);
                const data = await res.json();
                makeSelect.innerHTML = `<option value="">Selecciona una marca</option>`;
                if (data.status === "success" && data.data.makes) {
                    data.data.makes.forEach(m => {
                        const o = document.createElement("option");
                        o.value = m;
                        o.textContent = m;
                        makeSelect.appendChild(o);
                    });
                    makeSelect.disabled = false;
                }  else {
                     makeSelect.innerHTML = `<option value="">No se pudieron cargar las marcas</option>`;
                }
            } catch (e) {
                console.error("Error al cargar marcas:", e);
                 makeSelect.innerHTML = `<option value="">Error al cargar las marcas</option>`;
            } finally {
                hideLoading();
            }
        }

        async function getModelos() {
            const año = yearSelect.value;
            const marca = makeSelect.value;
            if (!año || !marca) return;
            showLoading();
            try {
                const res = await fetch(`backend/api/api_modelos.php?año=${encodeURIComponent(año)}&marca=${encodeURIComponent(marca)}`);
                const data = await res.json();
                modelSelect.innerHTML = `<option value="">Selecciona un modelo</option>`;
                if (data.status === "success" && data.data.models) {
                    data.data.models.forEach(m => {
                        const o = document.createElement("option");
                        o.value = m;
                        o.textContent = m;
                        modelSelect.appendChild(o);
                    });
                    modelSelect.disabled = false;
                } else {
                     modelSelect.innerHTML = `<option value="">No se pudieron cargar los modelos</option>`;
                }
            } catch (e) {
                console.error("Error al cargar modelos:", e);
                modelSelect.innerHTML = `<option value="">Error al cargar los modelos</option>`;
            } finally {
                hideLoading();
            }
        }

        async function getVersiones() {
            const año = yearSelect.value;
            const marca = makeSelect.value;
            const modelo = modelSelect.value;
            if (!año || !marca || !modelo) return;
            showLoading();
            try {
                const res = await fetch(`backend/api/api_versiones.php?año=${encodeURIComponent(año)}&marca=${encodeURIComponent(marca)}&modelo=${encodeURIComponent(modelo)}`);
                const data = await res.json();
                trimSelect.innerHTML = `<option value="">Selecciona una versión</option>`;
                if (data.status === "success" && data.data.trims) {
                    data.data.trims.forEach(v => {
                        const o = document.createElement("option");
                        o.value = v;
                        o.textContent = v;
                        trimSelect.appendChild(o);
                    });
                    trimSelect.disabled = false;
                } else {
                     trimSelect.innerHTML = `<option value="">No se pudieron cargar las versiones</option>`;
                }
            } catch (e) {
                console.error("Error al cargar versiones:", e);
                trimSelect.innerHTML = `<option value="">Error al cargar las versiones</option>`;
            } finally {
                hideLoading();
            }
        }

        yearSelect.addEventListener("change", () => {
            makeSelect.innerHTML = `<option value="">Cargando marcas...</option>`;
            makeSelect.disabled = true;
            modelSelect.innerHTML = `<option value="">Selecciona una marca primero</option>`;
            modelSelect.disabled = true;
            trimSelect.innerHTML = `<option value="">Selecciona un modelo primero</option>`;
            trimSelect.disabled = true;
            checkIfReadyToEnableButton();
            getMarcas();
        });

        makeSelect.addEventListener("change", () => {
            modelSelect.innerHTML = `<option value="">Cargando modelos...</option>`;
            modelSelect.disabled = true;
            trimSelect.innerHTML = `<option value="">Selecciona un modelo primero</option>`;
            trimSelect.disabled = true;
            checkIfReadyToEnableButton();
            getModelos();
        });

        modelSelect.addEventListener("change", () => {
            trimSelect.innerHTML = `<option value="">Cargando versiones...</option>`;
            trimSelect.disabled = true;
            checkIfReadyToEnableButton();
            getVersiones();
        });

        trimSelect.addEventListener("change", checkIfReadyToEnableButton);

        verMantenimientosBtn.addEventListener("click", () => {
            const año = encodeURIComponent(yearSelect.value);
            const marca = encodeURIComponent(makeSelect.value);
            const modelo = encodeURIComponent(modelSelect.value);
            const version = encodeURIComponent(trimSelect.value);
            window.location.href = `ver_mantenimientos.php?año=${año}&marca=${marca}&modelo=${modelo}&version=${version}`;
        });

        function showLoading() {
            loadingOverlay.style.display = 'flex';
        }

        function hideLoading() {
            loadingOverlay.style.display = 'none';
        }

        getAños();
    </script>
</body>
</html>


