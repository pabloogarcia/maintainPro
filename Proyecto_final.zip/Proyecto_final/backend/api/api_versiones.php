<?php
// backend/api_versiones.php
header('Content-Type: application/json');

if (!isset($_GET['año']) || !isset($_GET['marca']) || !isset($_GET['modelo'])) {
    echo json_encode(['status' => 'error', 'message' => 'Faltan parámetros (año, marca y/o modelo)']);
    exit();
}

$año   = urlencode($_GET['año']);
$marca  = urlencode($_GET['marca']);
$modelo = urlencode($_GET['modelo']);
$apiKey = " d00097003a1611f0bb3a0242ac120002";
$optionsURL = "https://api.vehicledatabases.com/vehicle-maintenance/options/v3/trim/{$año}/{$marca}/{$modelo}";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $optionsURL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["x-AuthKey: $apiKey"]);
$respuesta = curl_exec($ch);
curl_close($ch);

echo $respuesta;




?>

