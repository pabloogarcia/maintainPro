<?php
// backend/api_modelos.php
header('Content-Type: application/json');

if (!isset($_GET['año']) || !isset($_GET['marca'])) {
    echo json_encode(['status' => 'error', 'message' => 'Faltan parámetros (año y/o marca)']);
    exit();
}

$año = urlencode($_GET['año']);
$marca = urlencode($_GET['marca']);
$apiKey = "d00097003a1611f0bb3a0242ac120002";
$optionsURL = "https://api.vehicledatabases.com/vehicle-maintenance/options/v3/model/{$año}/{$marca}";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $optionsURL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["x-AuthKey: $apiKey"]);
$respuesta = curl_exec($ch);
curl_close($ch);

echo $respuesta;
?>
