<?php
// backend/api_años.php
header('Content-Type: application/json');

$apiKey = "d00097003a1611f0bb3a0242ac120002";
$optionsURL = "https://api.vehicledatabases.com/vehicle-maintenance/options/v3/year";

// Iniciamos la solicitud con cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $optionsURL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["x-AuthKey: $apiKey"]);
$respuesta = curl_exec($ch);
curl_close($ch);

echo $respuesta;
?>
