<?php
// backend/api_marcas.php
header('Content-Type: application/json');

if (!isset($_GET['año'])) {
    echo json_encode(['status' => 'error', 'message' => 'Falta el parámetro año']);
    exit();
}

$año = urlencode($_GET['año']);
$apiKey = "d00097003a1611f0bb3a0242ac120002";
$optionsURL = "https://api.vehicledatabases.com/vehicle-maintenance/options/v3/make/{$año}";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $optionsURL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["x-AuthKey: $apiKey"]);
$respuesta = curl_exec($ch);
curl_close($ch);

echo $respuesta;
?>
