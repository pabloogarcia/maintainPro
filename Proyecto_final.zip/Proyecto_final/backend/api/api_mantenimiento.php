<?php
// backend/api_mantenimiento.php
header('Content-Type: application/json');

if (!isset($_GET['año']) || !isset($_GET['marca']) || !isset($_GET['modelo']) || !isset($_GET['version'])) {
    echo json_encode(['status' => 'error', 'message' => 'Faltan parámetros (año, marca, modelo y/o version)']);
    exit();
}

$año    = urlencode($_GET['año']);
$marca   = urlencode($_GET['marca']);
$modelo  = urlencode($_GET['modelo']);
$version = urlencode($_GET['version']);
$apiKey = "d00097003a1611f0bb3a0242ac120002";
$mantenimientoURL = "https://api.vehicledatabases.com/vehicle-maintenance/v2/{$año}/{$marca}/{$modelo}/{$version}";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $mantenimientoURL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["x-AuthKey: $apiKey"]);
$respuesta = curl_exec($ch);
curl_close($ch);

echo $respuesta;
?>
