<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'C:/xampp/htdocs/Proyecto_final/vendor/autoload.php'; // Asegúrate de ajustar esta ruta según tu configuración

function enviarCorreo($destinatario, $asunto, $cuerpo) {
    $mail = new PHPMailer(true);
    $mail->SMTPDebug = 0; // Desactivar depuración en producción
    $mail->CharSet = 'UTF-8';
    $mail->addReplyTo('pablogarciamoreno2024@gmail.com', 'Soporte MaintainPro');

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Usa el host de tu proveedor SMTP
        $mail->SMTPAuth = true;
        $mail->Username = 'pablogarciamoreno2024@gmail.com'; // Tu correo
        $mail->Password = 's m p q n u u z x c o v d y p v'; // Tu contraseña o contraseña de la app
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Remitente y destinatario
        $mail->setFrom('pablogarciamoreno2024@gmail.com', 'Mantenimiento Vehículos');
        $mail->addAddress($destinatario);

        // Contenido
        $mail->isHTML(true); // Si deseas usar HTML, cambia esto a true y define el HTML
        $mail->Subject = $asunto;
        $mail->Body = $cuerpo;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Error al enviar el correo: {$mail->ErrorInfo}");
        return false;
    }
}
?>
