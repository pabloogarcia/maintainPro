<?php
session_start();
require '../config/db.php';

if (!isset($_SESSION["usuario_id"])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET["id"])) {
    $vehiculo_id = $_GET["id"];
    $usuario_id = $_SESSION["usuario_id"];

    $stmt = $conexion->prepare("DELETE FROM vehiculos_guardados WHERE id = ? AND usuario_id = ?");
    $stmt->bind_param("ii", $vehiculo_id, $usuario_id);
    $stmt->execute();
    $stmt->close();


    $_SESSION['mensaje_exito'] = "Vehículo eliminado correctamente.";
}

header("Location: ../../mis_vehiculos.php");
exit();
?>
