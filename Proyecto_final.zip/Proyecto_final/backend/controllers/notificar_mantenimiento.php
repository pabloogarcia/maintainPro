<?php
ob_start(); 
error_reporting(E_ALL);
ini_set('display_errors', 0); 
header('Content-Type: application/json');
session_start();


require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../helpers/mailer.php';

if (!isset($_GET['id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Faltan parámetros.']);
    exit();
}

$vehiculoId = intval($_GET['id']);

// Obtener los datos del vehículo
$sql = "SELECT * FROM vehiculos_guardados WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $vehiculoId);
$stmt->execute();
$resultado = $stmt->get_result();

if (!$vehiculo = $resultado->fetch_assoc()) {
    echo json_encode(['status' => 'success', 'message' => 'Vehículo no encontrado.']);
    exit();
}

// Calcular próxima revisión
$ultimaRevision = $vehiculo['ultima_revision'];
$proximaRevision = $ultimaRevision ? date('Y-m-d', strtotime($ultimaRevision . ' +1 year')) : 'No disponible';

$ultimaItv = $vehiculo['itv_fecha'];
$proximaItv = $ultimaItv ? date('Y-m-d', strtotime($ultimaItv . ' +1 year')) : 'No disponible';

$estadoItvTexto = 'No disponible';
$estadoItvClase = 'itv-neutra';

if ($ultimaItv) {
    $fechaLimiteItv = strtotime($ultimaItv . ' +1 year');
    if ($fechaLimiteItv < time()) {
        $estadoItvTexto = 'ITV caducada';
        $estadoItvClase = 'itv-caducada'; // Rojo
    } else {
        $estadoItvTexto = 'ITV en regla';
        $estadoItvClase = 'itv-ok'; // Verde
    }
}


// Obtener el correo del usuario
$usuarioId = $vehiculo['usuario_id'];
$sqlUsuario = "SELECT nombre, email FROM usuarios WHERE id = ?";
$stmtUsuario = $conexion->prepare($sqlUsuario);
$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();
$resultadoUsuario = $stmtUsuario->get_result();

if (!$usuario = $resultadoUsuario->fetch_assoc()) {
    echo json_encode(['status' => 'error', 'message' => 'Usuario no encontrado.']);
    exit();
}

$nombreUsuario = $usuario['nombre'];
$email = $usuario['email'];

$asunto = "Notificación de mantenimiento para su vehículo";
// Construir mensaje HTML
$mensaje = '
    <!DOCTYPE html>
    <html>
    <head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: \'Raleway\', sans-serif;
            background-color: #1e272e;
            color: #f1f1f1;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 30px auto;
            background-color: #2f3640;
            padding: 30px 20px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
        }
        .header {
            text-align: center;
            border-bottom: 1px solid #444;
            padding-bottom: 15px;
        }
        .header h1 {
            color: #08d9c8;
            font-size: 24px;
            margin: 0;
        }
        .content {
            margin-top: 25px;
            font-size: 16px;
            line-height: 1.6;
            color: #e0e0e0;
        }
        .content p {
            margin-bottom: 15px;
        }

        .itv-ok {
            color: #4caf50;
            font-weight: bold;
        }
        .itv-caducada {
            color: #ff4d4d;
            font-weight: bold;
        }
        .itv-neutra {
            color: #cccccc;
            font-weight: bold;
        }

        .button {
            display: inline-block;
            background-color: #08d9c8;
            color: #000000;
            padding: 12px 24px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            text-align: center;
            margin: 20px auto;
            display: block;
            width: fit-content;
            color: #000000 !important;
            text-decoration: none !important;
        }
        .button:hover {
            background-color: #008183;
            color: #ffffff;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #aaaaaa;
        }
    </style>
    </head>
    <body>
    <div class="container">
        <div class="header">
            <h1>Recordatorio de Revisión</h1>
            <img <img src="https://i.imgur.com/JKXmaHb.png" alt="Revisión Vehículo" style="max-width: 100%; height: auto; margin-top: 15px; border-radius: 10px;">
        </div>
        <div class="content">
            <p>Hola <strong>' . htmlspecialchars($nombreUsuario) . '</strong>,</p>
            <p>Recuerda que la próxima revisión de tu vehículo está programada para el <strong>' . htmlspecialchars($proximaRevision) . '</strong>.</p>
            <p><strong>Detalles del vehículo:</strong><br>
            Año: ' . htmlspecialchars($vehiculo['año']) . '<br>
            Marca: ' . htmlspecialchars($vehiculo['marca']) . '<br>
            Modelo: ' . htmlspecialchars($vehiculo['modelo']) . '<br>
            Versión: ' . htmlspecialchars($vehiculo['version']) . '</p>
            Próxima ITV: <strong>' . htmlspecialchars($proximaItv) . '</strong><br>
            <span class="' . $estadoItvClase . '">' . $estadoItvTexto . '</span></p>
            <p>¡Hazlo a tiempo para evitar problemas!</p>
            <a href="http://localhost/Proyecto_final/ver_mantenimientos.php?año=' . urlencode($vehiculo['año']) . '&marca=' . urlencode($vehiculo['marca']) . '&modelo=' . urlencode($vehiculo['modelo']) . '&version=' . urlencode($vehiculo['version']) . '" class="button">Ver detalles del vehículo</a>
            <p><strong>Saludos,<br>MaintainPro, Mantenimiento de Vehículos</strong></p>
        </div>
        <div class="footer">
            © ' . date("Y") . ' MaintainPro. Todos los derechos reservados.
        </div>
    </div>
    </body>
    </html>';

// Evitar duplicados
$sqlCheck = "SELECT id FROM notificaciones_vehiculo WHERE vehiculo_id = ? AND mensaje = ?";
$stmtCheck = $conexion->prepare($sqlCheck);
$stmtCheck->bind_param("is", $vehiculoId, $mensaje);
$stmtCheck->execute();
$checkResult = $stmtCheck->get_result();

if ($checkResult->num_rows > 0) {
    echo json_encode(['status' => 'success', 'message' => 'Ya se envió una notificación para este vehículo.']);
    exit();
}

// Enviar correo
if (enviarCorreo($email, $asunto, $mensaje)) {
    // Insertar la notificación en la base de datos
    $sqlInsert = "INSERT INTO notificaciones_vehiculo (vehiculo_id, mensaje) VALUES (?, ?)";
    $stmtInsert = $conexion->prepare($sqlInsert);
    $stmtInsert->bind_param("is", $vehiculoId, $mensaje);
    $stmtInsert->execute();

    // Establecer mensaje de éxito
    echo json_encode(['status' => 'success', 'message' => 'Notificación de mantenimiento enviada con éxito.']);

} else {
    // Establecer mensaje de error
    $_SESSION['mensaje_error'] = 'No se pudo enviar la notificación de mantenimiento.';

    // Devolver respuesta en JSON
    echo json_encode(['status' => 'error', 'message' => 'No se pudo enviar el correo.']);
}
?>
