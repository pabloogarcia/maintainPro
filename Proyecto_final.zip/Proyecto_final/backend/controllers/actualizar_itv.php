<?php
session_start();
require __DIR__ . '/../config/db.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION["usuario_id"];

$sql = "SELECT nombre, imagen_perfil FROM usuarios WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$stmt->bind_result($nombre, $imagen);
$stmt->fetch();
$stmt->close();

$imagen_perfil = empty($imagen)
    ? "https://www.kindpng.com/picc/m/24-248253_user-profile-default-image-png-clipart-png-download.png"
    : "backend/controllers/mostrar_imagen.php?id=$usuario_id";


$mensaje_error = '';
$mensaje_exito = '';
$vehiculo_seleccionado = null;
$vehiculos = [];

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];

// Obtener vehículos del usuario
// Obtener vehículos del usuario con la fecha ITV incluida
$stmt = $conexion->prepare("SELECT id, año, marca, modelo, version, itv_fecha FROM vehiculos_guardados WHERE usuario_id = ?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$vehiculos = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();


// Si se envió POST, procesar actualización
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_vehiculo = $_POST['id_vehiculo'] ?? null;
    $fecha_itv = $_POST['fecha_itv'] ?? null;

    if (!$id_vehiculo || !$fecha_itv) {
        $mensaje_error = "Por favor, seleccione un vehículo y una fecha válida.";
    } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha_itv)) {
        $mensaje_error = "Formato de fecha inválido.";
    } else {
        // Comprobar que el vehículo pertenece al usuario y obtener año
        $stmt = $conexion->prepare("SELECT año FROM vehiculos_guardados WHERE id = ? AND usuario_id = ?");
        $stmt->bind_param("ii", $id_vehiculo, $usuario_id);
        $stmt->execute();
        $stmt->bind_result($año_vehiculo);
        if ($stmt->fetch()) {
            $stmt->close();

            $años_vehiculo = (int)date('Y') - (int)$año_vehiculo;

            if ($años_vehiculo < 4) {
                $mensaje_error = "Este vehículo está exento de ITV hasta cumplir 4 años.";
            } else {
                $stmt_update = $conexion->prepare("UPDATE vehiculos_guardados SET itv_fecha = ? WHERE id = ? AND usuario_id = ?");
                $stmt_update->bind_param("sii", $fecha_itv, $id_vehiculo, $usuario_id);
                if ($stmt_update->execute()) {
                    $mensaje_exito = "Fecha de ITV actualizada correctamente.";

                    // Actualizar variable vehículo seleccionado para mostrar en el form si es necesario
                    foreach ($vehiculos as &$v) {
                        if ($v['id'] == $id_vehiculo) {
                            $vehiculo_seleccionado = $v;
                            break;
                        }
                    }
                } else {
                    $mensaje_error = "Error al actualizar la fecha de ITV.";
                }
                $stmt_update->close();
            }
        } else {
            $mensaje_error = "Vehículo no encontrado o no autorizado.";
            $stmt->close();
        }
    }
} else {
    // Si viene ID por GET, seleccionar vehículo para el formulario
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        foreach ($vehiculos as $veh) {
            if ($veh['id'] == $id) {
                $vehiculo_seleccionado = $veh;
                break;
            }
        }
    }
}

// Exportar variables para la vista
return [
    'vehiculos' => $vehiculos,
    'vehiculo_seleccionado' => $vehiculo_seleccionado,
    'mensaje_error' => $mensaje_error,
    'mensaje_exito' => $mensaje_exito,
];
