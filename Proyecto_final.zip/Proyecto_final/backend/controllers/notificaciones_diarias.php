<?php
require __DIR__ . '/../config/db.php';
require __DIR__ . '/../helpers/mailer.php';

$hoy = new DateTime();
$limite = new DateTime('+7 days');
$limite_str = $limite->format('Y-m-d');

$sql = "
    SELECT v.*, u.email, u.nombre
    FROM vehiculos_guardados v
    JOIN usuarios u ON v.usuario_id = u.id
    WHERE v.proxima_revision IS NOT NULL OR v.itv_fecha IS NOT NULL
";

$stmt = $conexion->prepare($sql);
$stmt->execute();
$resultado = $stmt->get_result();

while ($vehiculo = $resultado->fetch_assoc()) {
    $nombreUsuario = $vehiculo['nombre'];
    $email = $vehiculo['email'];
    $vehiculoNombre = $vehiculo['marca'] . ' ' . $vehiculo['modelo'];

    // ITV
    if (!empty($vehiculo['itv_fecha'])) {
        $fechaItv = new DateTime($vehiculo['itv_fecha']);
        $proximaItv = $fechaItv->modify('+1 year');
        $diffItv = (int)$hoy->diff($proximaItv)->format('%r%a');

        if ($diffItv >= 0 && $diffItv <= 7) {
            $mensajeItv ='
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;600&display=swap" rel="stylesheet">
                    <style>
                        body {
                            font-family: "Raleway", sans-serif;
                            background-color: #1e272e;
                            color: #f1f1f1;
                            margin: 0;
                            padding: 0;
                        }
                        .container {
                            max-width: 600px;
                            margin: 30px auto;
                            background-color: #2f3640;
                            padding: 30px 20px;
                            border-radius: 15px;
                            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
                        }
                        .header {
                            text-align: center;
                            border-bottom: 1px solid #444;
                            padding-bottom: 15px;
                        }
                        .header h1 {
                            color: #08d9c8;
                            font-size: 24px;
                            margin: 0;
                        }
                        .content {
                            margin-top: 25px;
                            font-size: 16px;
                            line-height: 1.6;
                            color: #e0e0e0;
                        }
                        .content p {
                            margin-bottom: 15px;
                        }
                        .button {
                            display: inline-block;
                            background-color: #08d9c8;
                            color: #000000;
                            padding: 12px 24px;
                            border-radius: 30px;
                            text-decoration: none;
                            font-weight: 600;
                            text-align: center;
                            margin: 20px auto;
                            display: block;
                            width: fit-content;
                            color: #000000 !important;
                            text-decoration: none !important;
                        }
                        .button:hover {
                            background-color: #008183;
                            color: #ffffff;
                        }
                        .footer {
                            margin-top: 30px;
                            text-align: center;
                            font-size: 12px;
                            color: #aaaaaa;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h1>Revision ITV proxima</h1>
                            
                            <img src="https://i.imgur.com/JKXmaHb.png" alt="Revisión Vehículo" style="max-width: 100%; height: auto; margin-top: 15px; border-radius: 10px;">
                        </div>
                        <div class="content">
                            <p>Hola <strong>' . htmlspecialchars($vehiculo['nombre']) . '</strong>,</p>
                            <p>Este es un recordatorio para informarte que tu vehículo <strong>' . htmlspecialchars($vehiculo['marca']) . ' ' . htmlspecialchars($vehiculo['modelo']) . '</strong> necesita pasar la ITV.</p>
                            <p><strong>Próxima ITV recomendada:</strong> ' . htmlspecialchars($proximaItv->format("Y-m-d")) . '</p>
                            <p>Para garantizar la seguridad y el rendimiento óptimo de tu vehículo, te recomendamos agendar una cita lo antes posible.</p>
                            <a href="http://localhost/Proyecto_final/ver_mantenimientos.php?año=' . urlencode($vehiculo['año']) . '&marca=' . urlencode($vehiculo['marca']) . '&modelo=' . urlencode($vehiculo['modelo']) . '&version=' . urlencode($vehiculo['version']) . '" class="button">Ver detalles del vehículo</a>
                            <p>Si ya pasaste la ITV, puedes ignorar este mensaje.</p>
                            <p><strong>– El equipo de MaintainPro</strong></p>
                        </div>
                        <div class="footer">
                            © ' . date("Y") . ' MaintainPro. Todos los derechos reservados.
                        </div>
                    </div>xº
                </body>
                </html>';
            enviarCorreo($email, "Recordatorio de ITV próxima", $mensajeItv);
        }
    }

    // Mantenimiento
    if (!empty($vehiculo['proxima_revision'])) {
        $fechaRevision = new DateTime($vehiculo['proxima_revision']);
        $diffRevision = (int)$hoy->diff($fechaRevision)->format('%r%a');

        if ($diffRevision >= 0 && $diffRevision <= 7) {
            $mensajeRevision = '
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;600&display=swap" rel="stylesheet">
                    <style>
                        body {
                            font-family: "Raleway", sans-serif;
                            background-color: #1e272e;
                            color: #f1f1f1;
                            margin: 0;
                            padding: 0;
                        }
                        .container {
                            max-width: 600px;
                            margin: 30px auto;
                            background-color: #2f3640;
                            padding: 30px 20px;
                            border-radius: 15px;
                            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
                        }
                        .header {
                            text-align: center;
                            border-bottom: 1px solid #444;
                            padding-bottom: 15px;
                        }
                        .header h1 {
                            color: #08d9c8;
                            font-size: 24px;
                            margin: 0;
                        }
                        .content {
                            margin-top: 25px;
                            font-size: 16px;
                            line-height: 1.6;
                            color: #e0e0e0;
                        }
                        .content p {
                            margin-bottom: 15px;
                        }
                        .button {
                            display: inline-block;
                            background-color: #08d9c8;
                            color: #000000;
                            padding: 12px 24px;
                            border-radius: 30px;
                            text-decoration: none;
                            font-weight: 600;
                            text-align: center;
                            margin: 20px auto;
                            display: block;
                            width: fit-content;
                            color: #000000 !important;
                            text-decoration: none !important;
                        }
                        .button:hover {
                            background-color: #008183;
                            color: #ffffff;
                        }
                        .footer {
                            margin-top: 30px;
                            text-align: center;
                            font-size: 12px;
                            color: #aaaaaa;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h1>Mantenimiento Recomendado</h1>
                            
                
                            <img src="https://i.imgur.com/JKXmaHb.png" alt="Revisión Vehículo" style="max-width: 100%; height: auto; margin-top: 15px; border-radius: 10px;">
                        </div>
                        <div class="content">
                            <p>Hola <strong>' . htmlspecialchars($vehiculo['nombre']) . '</strong>,</p>
                            <p>Este es un recordatorio para informarte que tu vehículo <strong>' . htmlspecialchars($vehiculo['marca']) . ' ' . htmlspecialchars($vehiculo['modelo']) . '</strong> necesita mantenimiento.</p>
                            <p><strong>Próxima revisión recomendada:</strong> ' . htmlspecialchars($vehiculo['proxima_revision']) . '</p>
                            <p>Para garantizar la seguridad y el rendimiento óptimo de tu vehículo, te recomendamos agendar una cita lo antes posible.</p>
                            <a href="http://localhost/Proyecto_final/ver_mantenimientos.php?año=' . urlencode($vehiculo['año']) . '&marca=' . urlencode($vehiculo['marca']) . '&modelo=' . urlencode($vehiculo['modelo']) . '&version=' . urlencode($vehiculo['version']) . '" class="button">Ver detalles del vehículo</a>
                            <p>Si ya realizaste el mantenimiento, puedes ignorar este mensaje.</p>
                            <p><strong>– El equipo de MaintainPro</strong></p>
                        </div>
                        <div class="footer">
                            © ' . date("Y") . ' MaintainPro. Todos los derechos reservados.
                        </div>
                    </div>
                </body>
                </html>';
            enviarCorreo($email, "Recordatorio de mantenimiento próximo", $mensajeRevision);
        }
    }
}
?>












