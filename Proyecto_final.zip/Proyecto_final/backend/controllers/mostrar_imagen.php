<?php
require_once '../config/db.php';


$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$sql = "SELECT imagen_perfil FROM usuarios WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($imagen_binaria);

if ($stmt->fetch() && !empty($imagen_binaria)) {
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $tipo = $finfo->buffer($imagen_binaria);

    // Limpia cualquier salida previa
    header("Content-Type: $tipo");
    echo $imagen_binaria;
} else {
    // Imagen por defecto si no hay imagen en la base de datos
    header("Location: https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png");
}
$stmt->close();
