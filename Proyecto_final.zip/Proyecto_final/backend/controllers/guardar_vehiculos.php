<?php
// backend/controllers/guardar_vehiculos.php
session_start();

// Incluir db.php
require '../config/db.php';

// Verificar si el usuario está autenticado
if (!isset($_SESSION["usuario_id"])) {
    header("Location: login.php");
    exit();
}   

$usuario_id = $_SESSION["usuario_id"];
$año = $_POST['año'] ?? '';
$marca = $_POST['marca'] ?? '';
$modelo = $_POST['modelo'] ?? '';
$version = $_POST['version'] ?? '';
$ultima_revision = $_POST['ultima_revision'] ?? '';

// Validar que la fecha de última revisión no sea futura
if (!empty($ultima_revision) && new DateTime($ultima_revision) > new DateTime()) {
    echo "La fecha de la última revisión no puede ser futura.";
    exit();
}

// Si se reciben los datos correctamente, insertar en la base de datos
if ($año && $marca && $modelo && $version && $ultima_revision) {
    // Calcular próxima revisión: 1 año después de la última
    $proxima_revision = date('Y-m-d', strtotime($ultima_revision . ' +1 year'));

    // Insertar todos los campos, incluyendo proxima_revision
    $stmt = $conexion->prepare("INSERT INTO vehiculos_guardados (usuario_id, año, marca, modelo, version, ultima_revision, proxima_revision) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssss", $usuario_id, $año, $marca, $modelo, $version, $ultima_revision, $proxima_revision);
    $stmt->execute();
    $stmt->close();
}

header("Location: ../../mis_vehiculos.php");  // Redirigir a la página de vehículos
exit();
?>
