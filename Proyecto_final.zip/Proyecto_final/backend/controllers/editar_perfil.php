<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../../login.php");
    exit;
}

$id = $_SESSION['usuario_id'];
$accion = $_POST['accion'] ?? '';

switch ($accion) {
    case 'actualizar_datos':
        $nombre = trim($_POST['nombre']);
        $email = trim($_POST['email']);

        if (empty($nombre) || empty($email)) {
            $_SESSION['error'] = "El nombre y el correo no pueden estar vacíos.";
            break;
        }

        $sql = "SELECT id FROM usuarios WHERE email = ? AND id != ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("si", $email, $id); 
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $_SESSION['error'] = "El correo electrónico ya está en uso por otro usuario.";
            $stmt->close();
            break;
        }
        $stmt->close();

        $sql = "UPDATE usuarios SET nombre = ?, email = ? WHERE id = ?";
        $stmt = $conexion->prepare($sql);
        if ($stmt === false) {
            $_SESSION['error'] = "Error en la preparación de la consulta.";
            break;
        }
        $stmt->bind_param("ssi", $nombre, $email, $id);
        if ($stmt->execute()) {
            $_SESSION['mensaje'] = "Datos modificados correctamente.";
        } else {
            $_SESSION['error'] = "Error al actualizar los datos.";
        }
        break;

    case 'cambiar_contraseña':
        $nueva_password = $_POST['password'] ?? '';
        if (empty($nueva_password)) {
            $_SESSION['error'] = "La nueva contraseña no puede estar vacía.";
            break;
        }

        // Validar seguridad de la contraseña
        if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $nueva_password)) {
            $_SESSION['error'] = "La contraseña debe tener al menos 8 caracteres, incluir una letra mayúscula, una minúscula y un número.";
            break;
        }

        $sql = "SELECT contraseña FROM usuarios WHERE id = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($password_actual_hash);
        $stmt->fetch();
        $stmt->close();

        if (password_verify($nueva_password, $password_actual_hash)) {
            $_SESSION['error'] = "La nueva contraseña debe ser diferente a la actual.";
            break;
        }

        $nueva_password_hash = password_hash($nueva_password, PASSWORD_BCRYPT);
        $sql = "UPDATE usuarios SET contraseña = ? WHERE id = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("si", $nueva_password_hash, $id);
        if ($stmt->execute()) {
            $_SESSION['mensaje'] = "Contraseña actualizada correctamente.";
        } else {
            $_SESSION['error'] = "Error al actualizar la contraseña.";
        }
        break;

    case 'cambiar_imagen':
        if (!isset($_FILES['imagen_perfil']) || $_FILES['imagen_perfil']['error'] !== UPLOAD_ERR_OK) {
            $_SESSION['error'] = "Error al cargar la imagen o no se seleccionó ninguna.";
            break;
        }

        $imagen = $_FILES['imagen_perfil'];
        $ext_permitidas = ['jpg', 'jpeg', 'png', 'gif'];
        $ext = strtolower(pathinfo($imagen['name'], PATHINFO_EXTENSION));

        if (!in_array($ext, $ext_permitidas)) {
            $_SESSION['error'] = "Formato de imagen no válido. Usa JPG, PNG o GIF.";
            break;
        }

        $tamaño_maximo = 2 * 1024 * 1024; // 2MB
        if (strlen($contenido_imagen) > $tamaño_maximo) {
            $_SESSION['error'] = "La imagen es demasiado grande. El tamaño máximo permitido es 2MB.";
            break;
        }

        $contenido_imagen = file_get_contents($imagen['tmp_name']);

        try {
            $sql = "UPDATE usuarios SET imagen_perfil = ? WHERE id = ?";
            $stmt = $conexion->prepare($sql);
            if ($stmt === false) {
                throw new Exception("Error al preparar la consulta.");
            }

            $stmt->send_long_data(0, $contenido_imagen);
            $stmt->bind_param("si", $contenido_imagen, $id);

            if ($stmt->execute()) {
                $_SESSION['mensaje'] = "Imagen de perfil actualizada correctamente.";
            } else {
                throw new Exception("Error al guardar la imagen en la base de datos.");
            }

            $stmt->close();
        } catch (Exception $e) {
            $_SESSION['error'] = "Error al subir la imagen: " . $e->getMessage();
        }

        break;
}

header("Location: ../../perfil.php");
exit;