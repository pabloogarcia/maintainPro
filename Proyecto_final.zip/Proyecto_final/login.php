<?php
session_start();
include 'backend/config/db.php';

$error = '';
$registroExitoso = false;

// Manejo de POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["action"]) && $_POST["action"] == "register") {
        $nombre = $_POST["nombre"];
        $email = $_POST["email"];
        $raw_password = $_POST["contraseña"];

        // Validar seguridad de la contraseña
        if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $raw_password)) {
            $error = "La contraseña debe tener al menos 8 caracteres, incluir una letra mayúscula, una minúscula y un número.";
        } else {
            $contraseña = password_hash($raw_password, PASSWORD_DEFAULT);

            // Verificar si el email ya está registrado
            $sql = "SELECT * FROM usuarios WHERE email = ?";
            $stmt = $conexion->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                $error = "El correo electrónico ya está registrado.";
            } else {
                $sql = "INSERT INTO usuarios (nombre, email, contraseña) VALUES (?, ?, ?)";
                $stmt = $conexion->prepare($sql);
                $stmt->bind_param("sss", $nombre, $email, $contraseña);

                if ($stmt->execute()) {
                    header("Location: " . $_SERVER['PHP_SELF'] . "?registro=exitoso");
                    exit();
                } else {
                    $error = "Error al registrar el usuario.";
                }
            }
        }
    } elseif (isset($_POST["action"]) && $_POST["action"] == "login") {
        $email = $_POST["email"];
        $contraseña = $_POST["contraseña"];

        $sql = "SELECT * FROM usuarios WHERE email = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            $usuario = $resultado->fetch_assoc();
            if (password_verify($contraseña, $usuario["contraseña"])) {
                $_SESSION["usuario_id"] = $usuario["id"];
                $_SESSION["nombre"] = $usuario["nombre"];
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Contraseña incorrecta.";
            }
        } else {
            $error = "Usuario no encontrado.";
        }
    }
}

// Para mantener el modo registro si corresponde
$mostrarRegistro = false;
if (
    ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["action"]) && $_POST["action"] == "register") ||
    (isset($_GET['mostrar']) && $_GET['mostrar'] === 'registro')
) {
    $mostrarRegistro = true;
}

// Mostrar mensaje de éxito si el registro fue exitoso
if (isset($_GET['registro']) && $_GET['registro'] === 'exitoso') {
    $registroExitoso = true;
}
?>

<!doctype html>
<html lang="es">
<head>
  <title>Webleb</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="frontend/css/login.css">
</head>
<body>

    <!-- Mensaje de error -->
    <?php if (!empty($error)): ?>
        <div class="alert alert-danger text-center" role="alert" id="error-alert">
            <strong>Error!</strong> <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <!-- Mensaje de registro exitoso -->
    <?php if ($registroExitoso): ?>
        <div class="alert alert-success text-center" role="alert" id="success-alert">
            <strong>¡Éxito!</strong> Usuario registrado correctamente. Ahora puedes iniciar sesión.
        </div>
    <?php endif; ?>

    <div class="section">
        <div class="container">
            <div class="row full-height justify-content-center">
                <div class="col-12 text-center align-self-center py-5">
                    <div class="section pb-5 pt-5 pt-sm-2 text-center">
                        <h4 class="mb-0 pb-3">
                            <span>Iniciar sesión </span>
                            <span>Registrarse</span>
                        </h4>
                        <input class="checkbox" type="checkbox" id="reg-log" name="reg-log"/>
                        <label for="reg-log"></label>
                        <div class="card-3d-wrap mx-auto">
                            <div class="card-3d-wrapper">
                                <!-- Formulario de Inicio de Sesión -->
                                <div class="card-front">
                                    <div class="center-wrap">
                                        <div class="section text-center">
                                            <h4 class="mb-4 pb-3">Iniciar sesión</h4>
                                            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                                <div class="form-group">
                                                    <input type="email" class="form-style" placeholder="Email" name="email" required>
                                                    <i class="input-icon uil uil-at"></i>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <input type="password" class="form-style" placeholder="Contraseña" name="contraseña" required>
                                                    <i class="input-icon uil uil-lock-alt"></i>
                                                </div>
                                                <input type="hidden" name="action" value="login">
                                                <button type="submit" class="btn mt-4">Iniciar sesión</button>
                                            </form>
                                            <p class="mb-0 mt-4 text-center">
                                                <a href="index.php" class="link">volver al inicio</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <!-- Formulario de Registro -->
                                <div class="card-back" id="register">
                                    <div class="center-wrap">
                                        <div class="section text-center">
                                            <h4 class="mb-3 pb-3">Registrarse</h4>
                                            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                                <div class="form-group">
                                                    <input type="text" class="form-style" placeholder="Nombre completo" name="nombre" required>
                                                    <i class="input-icon uil uil-user"></i>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <input type="email" class="form-style" placeholder="Email" name="email" required>
                                                    <i class="input-icon uil uil-at"></i>
                                                </div>
                                                <div class="form-group mt-2">
                                                    <input type="password" class="form-style" placeholder="Contraseña" name="contraseña" required>
                                                    <i class="input-icon uil uil-lock-alt"></i>
                                                </div>
                                                <input type="hidden" name="action" value="register">
                                                <button type="submit" class="btn mt-4">Registrarse</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div> <!-- card-3d-wrapper -->
                        </div> <!-- card-3d-wrap -->
                    </div> <!-- section -->
                </div> <!-- col-12 -->
            </div> <!-- row -->
        </div> <!-- container -->   
    </div> <!-- section -->

    <?php if ($mostrarRegistro): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.getElementById("reg-log").checked = true;
        });
    </script>
    <?php endif; ?>
    
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Activar el formulario de registro si corresponde
            <?php if ($mostrarRegistro): ?>
            document.getElementById("reg-log").checked = true;
            <?php endif; ?>

            // Desvanecer alertas tras 4 segundos
            setTimeout(() => {
            const errorAlert = document.getElementById("error-alert");
            const successAlert = document.getElementById("success-alert");

            if (errorAlert) errorAlert.classList.add("fade-out");
            if (successAlert) successAlert.classList.add("fade-out");
            }, 4000);
        });
    </script>


</body>
</html>
